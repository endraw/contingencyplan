Designing Arcade Computer Game Graphics
========================================

Copyright (c) 2000 by Ari Feldman.

Distributed with permission by Mark Overmars.